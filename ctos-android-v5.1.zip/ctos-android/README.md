# ctOS — Android PWA, Professional Edition 5.1

An offline-first fictional database interface. It stores profiles, folders, notes, files and attachments in the browser's IndexedDB. It does **not** connect to networks, scan people, access accounts, or perform real hacking.

## Install on Android
1. Extract `ctos-android.zip` on a computer or phone.
2. Host the extracted folder on a static HTTPS host (for example GitHub Pages or another static web host). PWAs require HTTPS (localhost is the exception); opening `index.html` as a `file://` URL will not enable install/offline service-worker features.
3. Open the HTTPS address in Chrome on Android, allow the first load to finish, then use Chrome menu → **Install app** or **Add to Home screen**.
4. Launch ctOS from the home screen. After the first successful load, the app shell works offline. IndexedDB data remains on that browser installation.

A simple local preview on a computer: from this folder run `python -m http.server 8000`, then open `http://localhost:8000`. This is for testing on that computer; Android installation requires an HTTPS host.

## Features
- Startup boot sequence and synthesized Web Audio tones (sound begins after user interaction on some browsers).
- Dashboard, local profiler, database index, file manager, status and settings.
- Create/edit/delete/search profiles and files; create/delete folders.
- Optional profile images and file attachments (per-file attachment limit 5 MB; profile image limit 3 MB).
- JSON backup export/import including attachment data.
- File sorting by newest, oldest, name or category.
- Inline image attachment previews and PDF previews where supported.
- Demo file access terminal. Code: `8639`. This is a theatrical UI gate only, not encryption or meaningful security.
- Service worker app-shell caching for offline launch.

## Storage and privacy
All user-created records stay in the current browser's IndexedDB unless the user exports a backup. Clearing browser site data may erase them. Backups contain the stored records and attachments; keep them private. No analytics or remote profile lookups are implemented. The visual typeface is requested from Google Fonts when online; system monospace fonts are used offline.

## Browser support
Modern Android Chrome is recommended. The app requires IndexedDB, File APIs, Web Audio for tones, and service-worker/PWA support for installability. It is a PWA rather than a native APK; it installs from the browser.
